export class Usuario {
    usuarioId: string;
    username: string;
    contrasena: string;
    nombreCompleto: string;
    token?: string;
}